package com.arquitecturajava.cursomaven.matematicas;

public class Calculadora {

	public static double sumar(double a, double b) {

		return a + b;
	}

	// VERSION 0.2
	public static double restar(double a, double b) {

		return a - b;

	}

	// VERSION 0.3 HECHO EN LA PARTE FINANCIERA
			public static double sumarValores(double... valores) {
				double total = 0;
				for (double valor : valores) {
					
					total+=valor;

				}
				return total;
			}
				
			}


