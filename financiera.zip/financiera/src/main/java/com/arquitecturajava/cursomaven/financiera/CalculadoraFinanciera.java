package com.arquitecturajava.cursomaven.financiera;

import com.arquitecturajava.cursomaven.matematicas.Calculadora;

public class CalculadoraFinanciera {
	
	//Depende de la version 0.3 de la calculadora. 
	public static double sumarImportes(double... importes) {

		return Calculadora.sumarValores(importes);

	}

}
